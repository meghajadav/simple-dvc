from setuptools import setup, find_packages

setup(
    name='src',
    version='0.0.1',
    description="it's a wine package",
    author='Megha',
    packages=find_packages(),
    license='MIT'
)